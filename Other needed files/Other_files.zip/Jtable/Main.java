import javax.swing.*;
import java.awt.*;
import java.awt.event.*;;
import java.util.ArrayList;
import javax.swing.table.*;



public class Main{
	
	public static void main(String[] args)
	{
		
		new JTable1();
		
		
		
	}
	
	
	
}