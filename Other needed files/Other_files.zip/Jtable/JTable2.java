import javax.swing.*;
import java.awt.*;
import java.awt.event.*;;
import java.util.ArrayList;
import javax.swing.table.*;

public class JTable2 extends JPanel{
	
	static Object[][] databaseInfo;
	static DefaultTableModel dTableModel;
	
	public JTable2()
	{
		this.setBounds(0,0,500,500);
		addComponentToPanel();
	}
	
	
	public void addComponentToPanel()
	{
		
		Object[] columns = {"CourseId", "CourseName", "CourseFee" , "BuyNow"};
		
				BasicU b = new BasicU("good" , "bad" , "better");
				
				dTableModel = new DefaultTableModel(databaseInfo, columns);
				
				ArrayList<BasicU> list = new ArrayList<BasicU>();
				

				Object[] tempRow = new Object[4];
				list.add(b);
				
				for(int i=0;i<list.size();i++){
					
					tempRow[0]=list.get(0).s1();
					tempRow[1]=list.get(0).s2();
					tempRow[2]=list.get(0).s3();
					tempRow[3] = new JButton("Ok");
					
					dTableModel.addRow(tempRow);
				}
				
				JTable table = new JTable(dTableModel);
				table.setRowHeight(table.getRowHeight()+10);
				table.setAutoCreateRowSorter(true);
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

				TableColumn col1 = table.getColumnModel().getColumn(0);
				col1.setPreferredWidth(100);
				
				TableColumn col2 = table.getColumnModel().getColumn(1);
				col2.setPreferredWidth(190);
				
				TableColumn col3 = table.getColumnModel().getColumn(2);
				col3.setPreferredWidth(150);
				
				JScrollPane scrollPane = new JScrollPane(table);
				scrollPane.setBounds(50,50,458,100);
				add(scrollPane);
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
}