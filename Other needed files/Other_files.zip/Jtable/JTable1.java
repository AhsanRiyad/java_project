import javax.swing.*;
import java.awt.*;
import java.awt.event.*;;
import java.util.ArrayList;
import javax.swing.table.*;




public class JTable1 extends JFrame{
	JTable2 j;
	
	public  JTable1()
	{
		this.setTitle("JFrame");
		this.setSize(600,600);
		// this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		
		
		addComponentToFrame();
		
		
		this.setVisible(true);
		
	}
	
	
	public void addComponentToFrame()
	{
		j =  new JTable2();
		this.add(j);
	
	}
	
	
	
	
	
}