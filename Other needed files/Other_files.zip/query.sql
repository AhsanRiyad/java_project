create table Seller (
	sellerId varchar(50) not null,
	sellerName varchar(50) not null,
	sellerEmail varchar(50) not null,
	sellerMobile int(50) not null,

	constraint sellerNumberPrimaryKey primary key(sellerId)	

	)


create table Customer (
	customerId varchar(50) not null,
	customerName varchar(50) not null,
	customerEmail varchar(50) not null,
	customerMobile int(50) not null,

	constraint CustomerNumberPrimaryKey primary key(customerId)	

	)













create table LogIn(

	sellerId varchar(50),
	customerId varchar(50),
	password varchar(30) not null , 


	constraint LogInSellerIdForeignKey foreign key(sellerId) references seller(sellerId),
	constraint LoginCustomerIdForeignKey foreign key(customerId) references customer(customerId)

	)





create table msg(
	msgId int(255) not null AUTO_INCREMENT , 
	msgText varchar(300) not null,

	constraint msgPrimaryKey primary key(msgId)



)


create table send(
	customerId varchar(50) not null,
	sellerId varchar(50) not null,
	msgId int(255) not null,


	constraint msgCustomerIdForeignKey foreign key(customerId) references customer(customerId),
	constraint msgSellerIdForeignKey foreign key(sellerId) references seller(sellerId),
	constraint msgMsgIdForeignKey foreign key(msgId) references msg(msgId),
	constraint msgCompositePrimaryKey primary key(customerId, sellerId, msgId)


)


create table order_product (
	orderId int(50),
	orderDate date ,
	orderStatus varchar(50),
	customerId varchar(50),


	constraint orderCustomerIdForeignKey foreign key(customerId) references customer(customerId),

	constraint orderIdPrimaryKey primary key(orderId)
)




create table delivers(
	orderId int(50),
	sellerId varchar(50),
	deliveryDate date,

	constraint deliversOrderIdForeignKey foreign key(orderId) references order_product(orderId),
	constraint deliversSellerIdForeignKey foreign key(sellerId) references seller(sellerId),
	constraint deliversPrimaryKey primary key(orderId , sellerId)




)



create table product(

	productId int(50) not null,
	productName varchar(100),
	productDescription varchar(300),
	productCostPerUnit int(50),
	productSellingPricePerUnit int(50),
	productRemainingQuantity int(50),


	constraint productPrimaryKey primary key(productId)





)




create table contains(

	orderId int(50),
	productId int(50),
	perProductQuantity int(50),


	constraint containsOrderIdForeignKey foreign key(orderId) references order_product(orderId),
	constraint containsProductIdForeignKey foreign key(productId) references product(productId),
	constraint containsPrimaryKey primary key(orderId , productId)





)





create table updateProduct(

	orderId int(50),
	productId int(50),
	sellerId varchar(50),
	updateDate date,


	constraint updateOrderIdForeignKey foreign key(orderId) references order_product(orderId),
	constraint updateProductIdForeignKey foreign key(productId) references product(productId),
	constraint updateSellerIdForeignKey foreign key(sellerId) references seller(sellerId),
	constraint updatePrimaryKey primary key(orderId, productId, sellerId)



)



insert into customer values('Riyad' , 'Riyad Ahsan' , 'riyad@gmail.com' ,'01919448787' )

