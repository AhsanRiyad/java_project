create table Seller (
	sellerId varchar(50) not null,
	sellerName varchar(50) not null,
	sellerEmail varchar(50) not null UNIQUE,
	sellerMobile int(50) not null,

	constraint sellerNumberPrimaryKey primary key(sellerId)	

	)


create table Customer (
	customerId varchar(50) not null,
	customerName varchar(50) not null,
	customerEmail varchar(50) not null UNIQUE,
	customerMobile int(50) not null,

	constraint CustomerNumberPrimaryKey primary key(customerId)	

	)













create table LogIn(

	sellerId varchar(50),
	customerId varchar(50),
	password varchar(30) not null 



	)





create table msg(
	msgId int(255) null AUTO_INCREMENT , 
	msgText varchar(300) null,
	userid varchar(200) null,

	constraint msgPrimaryKey primary key(msgId)



)


create table send(
	customerId varchar(50) not null,
	sellerId varchar(50) not null,
	msgId int(255) not null,

	constraint msgCompositePrimaryKey primary key(customerId, sellerId, msgId)


)


create table order_product (
	orderId int(50),
	orderDate date ,
	orderStatus varchar(50),
	customerId varchar(50),


	constraint orderIdPrimaryKey primary key(orderId)
)




create table delivers(
	orderId int(50),
	sellerId varchar(50),
	deliveryDate date,

	constraint deliversPrimaryKey primary key(orderId , sellerId)




)



create table product(

	productId int(50) not null,
	productName varchar(100),
	productDescription varchar(300),
	productCostPerUnit int(50),
	productSellingPricePerUnit int(50),
	productRemainingQuantity int(50),


	constraint productPrimaryKey primary key(productId)





)




create table contains(

	orderId int(50),
	productId int(50),
	perProductQuantity int(50),

	constraint containsPrimaryKey primary key(orderId , productId)





)





create table updateProduct(

	orderId int(50),
	productId int(50),
	sellerId varchar(50),
	updateDate date,

	constraint updatePrimaryKey primary key(orderId, productId, sellerId)



)



insert into customer values('Riyad' , 'Riyad Ahsan' , 'riyad@gmail.com' ,'01919448787' )

